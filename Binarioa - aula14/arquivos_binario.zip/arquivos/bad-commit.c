#include "utils.h"

/* */
int bad_commit (int *A, int n) {
  /*Terminar*/	
} 

/* */
int main () {
  int i;
  int n = 7;
  int A[] = {0,0,0,0,0,0,1};
  printf("Bad commit: %d\n", bad_commit(A, n));
  return 0;
}
