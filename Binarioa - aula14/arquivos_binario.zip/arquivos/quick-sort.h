#include "utils.h"

int partition_string (char **A, int left, int right);

int partition (int A[], int left, int right);

void quick_sort (int *A, int left, int right);

void quick_sort_string (char **A, int left, int right);
